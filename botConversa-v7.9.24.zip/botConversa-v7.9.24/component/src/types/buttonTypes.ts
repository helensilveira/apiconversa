import {FILE_TYPES} from './fileTypes';

export type BUTTON_TYPES = FILE_TYPES | 'camera' | 'microphone' | 'submit';

import './serviceCode.css';
import React from 'react';

export default function Code({code}) {
  return <pre id="service-code">{code}</pre>;
}

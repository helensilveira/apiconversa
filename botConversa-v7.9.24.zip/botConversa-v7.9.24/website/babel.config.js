module.exports = {
  presets: [require.resolve('@botconversa/core/lib/babel/preset')],
};

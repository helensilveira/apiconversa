package com.server.utils.types;

public class HugginFaceSpeechResult {
  private String text;

  public String getText() {
    return this.text;
  }
}
